import sqlite3

class Database:
    def __init__(self,db):
        self.conn = sqlite3.connect(db)
        self.cur = self.conn.cursor()

    def login_user(self,userid,password):
        self.cur.execute("SELECT * FROM admin_user WHERE userid = '"+userid+"' AND password = '"+password+"'")
        self.u_data = self.cur.fetchone()
        return self.u_data
    
    def check_book_s_n(self,bookid):
        self.cur.execute("SELECT * FROM book_str WHERE book_id = ?",(bookid,))
        res = self.cur.fetchall()
        if res != []:
            return True
        else:
            return False

    def add_book(self,bookid,bookName,author,price):
        self.cur.execute("INSERT INTO book_str(book_id,title,author_nme,price) VALUES(?,?,?,?)",(bookid,bookName,author,price,))
        self.conn.commit()
        return self.cur.lastrowid
    
    def check_pend_isue_b_st(self,stud_id):
        self.cur.execute("SELECT * FROM issue_book WHERE studentid = '"+stud_id+"'")
        res = self.cur.fetchall()
        return res
    
    def select_stu_data(self,stud_id):
        self.cur.execute("SELECT * FROM student WHERE admin_no = '"+stud_id+"'")
        return self.cur.fetchone()
    
    def add_student(self,studid,sname,sclass,semail):
        self.cur.execute("INSERT INTO student(admin_no,name,class,email) VALUES(?,?,?,?)",(studid,sname,sclass,semail,))
        self.conn.commit()
        return self.cur.lastrowid
    
    def update_student(self,studid,sname,sclass,semail):
        self.cur.execute("UPDATE student SET name=?,class=?,email=? WHERE admin_no = ?",(sname,sclass,semail,studid))
        self.conn.commit()
    
    def select_book_details(self,bookid):
        self.cur.execute("SELECT * FROM book_str WHERE book_id='"+bookid+"'")
        return self.cur.fetchone()
    
    def update_book(self,bookID,bookName,authorName,bookPrice):
        self.cur.execute("UPDATE book_str SET title=?,author_nme=?,price=? WHERE book_id=?",(bookName,authorName,bookPrice,bookID))
        self.conn.commit()
    
    def check_issued_book(self,bookID):
        self.cur.execute("SELECT * FROM issue_book WHERE bookid = '"+bookID+"' AND submit_date='0'")
        return self.cur.fetchall()

    def check_book_aval(self,bookID):
        self.cur.execute("SELECT * FROM book_str WHERE book_id = '"+bookID+"'")
        return self.cur.fetchall()

    def delete_book(self,bookID):
        self.cur.execute("DELETE FROM book_str WHERE book_id='"+bookID+"'")
        self.conn.commit()