import json
import sys
from PyQt5.uic import loadUi
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import QTimer,QTime,Qt
from database import Database
from datetime import date

db = Database("db/lms.db")

class Search_Book(QWidget):
    def __init__(self):
        super(Delete_Book,self).__init__()
        loadUi("ui/lms_searchBook.ui",self)
        self.back_btn.clicked.connect(self.backtodash)
    
    def backtodash(self):
        dashboard = Dashboard()
        widget.addWidget(dashboard)
        widget.setCurrentIndex(widget.currentIndex() + 1)

class Show_Book(QWidget):
    pass

class Delete_Book(QWidget):
    def __init__(self):
        super(Delete_Book,self).__init__()
        loadUi("ui/lms_deleteBook.ui",self)
        self.onlyInt = QIntValidator()
        self.bookID.setValidator(self.onlyInt)
        self.back_btn.clicked.connect(self.backtodash)
        self.deleteBookBtn.clicked.connect(self.delete_book)
    
    def delete_book(self):
        bookID=self.bookID.text()
        if len(bookID)==0:
            msg_book=QMessageBox(self)
            msg_book.setWindowTitle("Library Management System")
            msg_book.setText("Please enter book id. It's required!!!")
            msg_book.exec_()
        elif db.check_issued_book(bookID) != []:
            msg_book=QMessageBox(self)
            msg_book.setWindowTitle("Library Management System")
            msg_book.setText("This book is issued. You can't delete any issued book.")
            msg_book.exec_()
            self.bookID.clear()
        elif db.check_book_aval(bookID) == []:
            msg_book=QMessageBox(self)
            msg_book.setWindowTitle("Library Management System")
            msg_book.setText("There is no any book with your given book id.")
            msg_book.exec_()
            self.bookID.clear()
        else:
            db.delete_book(bookID)
            msg_book=QMessageBox(self)
            msg_book.setWindowTitle("Library Management System")
            msg_book.setText("Book deleted successfully.")
            msg_book.exec_()
            self.bookID.clear()

    def backtodash(self):
        dashboard = Dashboard()
        widget.addWidget(dashboard)
        widget.setCurrentIndex(widget.currentIndex() + 1)

class Return_Book(QWidget):
    pass

class Edit_Book(QWidget):
    def __init__(self):
        super(Edit_Book,self).__init__()
        loadUi("ui/lms_editBook.ui",self)
        self.back_btn.clicked.connect(self.backtodash)
        self.book_frame.setHidden(True)
        self.search_book_btn.clicked.connect(self.search_book_details)
    
    def search_book_details(self):
        bookid=self.book_id.text()
        if len(bookid)==0:
            self.book_frame.setHidden(True)
            msg_book=QMessageBox(self)
            msg_book.setWindowTitle("Library Management System")
            msg_book.setText("Fields are required!!!")
            msg_book.exec_()
        else:
            res=db.select_book_details(bookid)
            if res != None:
                self.book_frame.setHidden(False)
                self.book_id_u.setReadOnly(True)
                self.book_id_u.setText(str(res[1]))
                self.book_name.setText(str(res[2]))
                self.authors_name.setText(str(res[3]))
                self.book_price.setText(str(res[4]))
                self.update_book_btn.clicked.connect(self.update_book_details)
            else:
                self.book_frame.setHidden(True)
                msg_book=QMessageBox(self)
                msg_book.setWindowTitle("Library Management System")
                msg_book.setText("There is no any book with this book id.")
                msg_book.exec_()
    
    def update_book_details(self):
        bookid=self.book_id.text()
        bookName=self.book_name.text()
        authorName=self.authors_name.text()
        bookPrice=self.book_price.text()
        if len(bookName)==0 or len(authorName)==0 or len(bookPrice)==0:
            msg_box = QMessageBox(self)
            msg_box.setWindowTitle("Library Management System")
            msg_box.setText("All fields are required.")
            msg_box.exec_()
        else:
            db.update_book(bookid,bookName,authorName,bookPrice)
            msg_box=QMessageBox(self)
            msg_box.setWindowTitle("Library Management System")
            msg_box.setText("Book details are updated successfully.")
            msg_box.exec_()

    def backtodash(self):
        dashboard = Dashboard()
        widget.addWidget(dashboard)
        widget.setCurrentIndex(widget.currentIndex() + 1)

class Issue_Book(QWidget):
    def __init__(self):
        super(Issue_Book,self).__init__()
        loadUi("ui/lms_issueBook.ui",self)
        self.back_btn.clicked.connect(self.backtodash)
        self.stud_frame.setHidden(True)
        self.issue_frame.setHidden(True)
        self.find_stu_btn.clicked.connect(self.find_stud_func)
    
    def find_stud_func(self):
        studid = self.stu_admin_no.text()
        no = len(db.check_pend_isue_b_st(studid))
        self.stud_frame.setHidden(False)
        self.save_stu_data.setEnabled(True)
        self.issued_status.setText(f"Issued Book: {no}")
        res = db.select_stu_data(studid)
        if res != None:
            self.issue_frame.setHidden(True)
            self.stu_admin_no_2.setText(str(res[1]))
            self.stu_admin_no_2.setReadOnly(True)
            self.stud_name.setText(str(res[2]))
            self.student_class.setText(str(res[3]))
            self.stud_email.setText(str(res[4]))
            self.save_stu_data.clicked.connect(self.update_stud_data)
        else:
            self.issue_frame.setHidden(True)
            self.clear_fields()
            self.stu_admin_no_2.setReadOnly(False)
            self.save_stu_data.clicked.connect(self.save_stud_data)
    
    def save_stud_data(self):
        admin_no=self.stu_admin_no_2.text()
        sname=self.stud_name.text()
        sclass=self.student_class.text()
        semail=self.stud_email.text()

        if self.validate_fields(admin_no,sname,sclass,semail) != True:
            mes_box = QMessageBox(self)
            mes_box.setIcon(QMessageBox.Warning)
            mes_box.setWindowTitle("Library Management System")
            mes_box.setText("All fields are required. Please fill and retry.")
            mes_box.exec_()
        else:
            if db.add_student(admin_no,sname,sclass,semail) != "":
                self.issue_frame.setHidden(False)
                self.save_stu_data.setEnabled(False)
            else:
                mes_box = QMessageBox(self)
                mes_box.setIcon(QMessageBox.Warning)
                mes_box.setWindowTitle("Library Management System")
                mes_box.setText("Something went wrong while saving student data. Try Again!!!! or Report it to devloper.")
                mes_box.exec_()
    
    def update_stud_data(self):
        admin_no=self.stu_admin_no_2.text()
        sname=self.stud_name.text()
        sclass=self.student_class.text()
        semail=self.stud_email.text()
        if self.validate_fields(admin_no,sname,sclass,semail) != True:
            mes_box = QMessageBox(self)
            mes_box.setIcon(QMessageBox.Warning)
            mes_box.setWindowTitle("Library Management System")
            mes_box.setText("All fields are required. Please fill and retry.")
            mes_box.exec_()
        else:
            db.update_student(admin_no,sname,sclass,semail)
            self.issue_frame.setHidden(False)
            self.save_stu_data.setEnabled(False)

    def validate_fields(self,admin_no,sname,sclass,semail):
        if len(admin_no) == 0 or len(sname)==0 or len(sclass)==0 or len(semail)==0:
            return False
        else:
            return True

    def clear_fields(self):
        self.stu_admin_no_2.clear()
        self.stud_name.clear()
        self.student_class.clear()
        self.stud_email.clear()

    def backtodash(self):
        dashboard = Dashboard()
        widget.addWidget(dashboard)
        widget.setCurrentIndex(widget.currentIndex() + 1)

class Add_Book(QWidget):
    def __init__(self):
        super(Add_Book,self).__init__()
        loadUi("ui/lms_addBook.ui",self)
        self.onlyInt = QIntValidator()
        self.book_id.setValidator(self.onlyInt)
        self.book_price.setValidator(self.onlyInt)
        self.save_book_data.clicked.connect(self.add_book_rec)
        self.back_btn.clicked.connect(self.backtodash)

    def add_book_rec(self):
        book_id = self.book_id.text()
        book_name = self.book_name.text()
        author_name = self.author_name.text()
        book_price = self.book_price.text()

        if len(book_id) == 0 or len(book_name) == 0 or len(author_name) == 0 or len(book_price) == 0:
            self.err_txt.setText("")
            self.err_txt.setText("All fields are required. Please fill then retry.")
        else:
            res = db.check_book_s_n(book_id)
            if res == False:
                self.err_txt.setText("")
                res = db.add_book(book_id,book_name,author_name,book_price)
                if res != "":
                    self.err_txt.setText("")
                    self.err_txt.setText("Book saved to database successfully.")
                    self.book_id.clear()
                    self.book_name.clear()
                    self.author_name.clear()
                    self.book_price.clear()
                else:
                    self.err_txt.setText("")
                    self.err_txt.setText("Error in saving book data.")
            else:
                self.err_txt.setText("")
                self.err_txt.setText("Book id already taken.")
    
    def backtodash(self):
        dashboard = Dashboard()
        widget.addWidget(dashboard)
        widget.setCurrentIndex(widget.currentIndex() + 1)

class Dashboard(QWidget):
    def __init__(self):
        super(Dashboard,self).__init__()
        loadUi("ui/lms_dashboard.ui",self)
        with open("config/config.json", "r+") as f:
            u_data = json.load(f)
        self.usr_txt.setText("Hello "+u_data["data"][1]+"!")
        date_t=date.today()
        self.date_l.setText(str(date_t.strftime("%a, %d %Y")))
        timer = QTimer(self)
        timer.timeout.connect(self.show_time)
        timer.start(1000)
        self.logout_btn.clicked.connect(self.logout_func)
        self.add_book_btn.clicked.connect(self.add_book_func)
        self.issue_book_btn.clicked.connect(self.issue_book_func)
        self.edit_book_btn.clicked.connect(self.edit_book_screen)
        self.delete_book_btn.clicked.connect(self.delete_book_screen)
        self.search_book_btn.clicked.connect(self.search_book_screen)
    
    def show_time(self):
        current_time = QTime.currentTime()
        label_time = current_time.toString("hh:mm:ss")
        self.time_l.display(label_time)
    
    def logout_func(self):
        widget.close()
        with open("config/config.json", "r+") as f:
            data = json.load(f)
            data["login"] = "N"
            data["data"] = ()
            f.seek(0)
            json.dump(data, f)
            f.truncate()
        self.goto_login()
    
    def goto_login(self):
        self.login = Login()
        self.login.show()
    
    def add_book_func(self):
        addBook = Add_Book()
        widget.addWidget(addBook)
        widget.setCurrentIndex(widget.currentIndex() + 1)
    
    def issue_book_func(self):
        issueBook = Issue_Book()
        widget.addWidget(issueBook)
        widget.setCurrentIndex(widget.currentIndex() + 1)
    
    def edit_book_screen(self):
        editBook = Edit_Book()
        widget.addWidget(editBook)
        widget.setCurrentIndex(widget.currentIndex() + 1)
    
    def delete_book_screen(self):
        deleteBook = Delete_Book()
        widget.addWidget(deleteBook)
        widget.setCurrentIndex(widget.currentIndex() + 1)
    
    def search_book_screen(self):
        searchBook=Search_Book()
        widget.addWidget(searchBook)
        widget.setCurrentIndex(widget.currentIndex() + 1)

class Login(QMainWindow):
    def __init__(self):
        super(Login, self).__init__()
        loadUi("ui/lms_login.ui", self)
        self.setWindowTitle("Login")
        self.setFixedHeight(444)
        self.setFixedWidth(514)
        self.move(500,130)
        self.login_btn.clicked.connect(self.loginfunction)
        self.login_clear_btn.clicked.connect(self.clear_f)
    
    def loginfunction(self):
        userid = self.user_id.text()
        password = self.password_f.text()
        if userid != "" and password != "":
            self.error_mes.setText("")
            res = db.login_user(userid,password)
            if res != None:
                with open("config/config.json", "r+") as f:
                    data = json.load(f)
                    data["login"] = "Y"
                    data["data"] = res
                    f.seek(0)
                    json.dump(data, f)
                    f.truncate()
                msg_box = QMessageBox(self)
                msg_box.setWindowTitle("Library Management System")
                msg_box.setText("Successfully logined.")
                msg_box.exec_()
                self.close()
                self.goto_dashboard()
            else:
                msg_box = QMessageBox(self)
                msg_box.setWindowTitle("Library Management System")
                msg_box.setText("Invalid User ID or Password.")
                msg_box.exec_()
        else:
            self.error_mes.setText("* User ID and Password are required.")

    def clear_f(self):
        self.user_id.clear()
        self.password_f.clear()
    
    def goto_dashboard(self):
        dashboard = Dashboard()
        widget.addWidget(dashboard)
        widget.setWindowTitle("Library Management System")
        widget.setFixedWidth(643)
        widget.setFixedHeight(478)
        widget.move(470,130)
        widget.show()


if __name__ == "__main__":
    f = open("config/config.json","r")
    status = json.load(f)
    if status["login"] == "Y" and status["data"] != None:
        app = QApplication(sys.argv)
        dashboard = Dashboard()
        widget = QStackedWidget()
        widget.addWidget(dashboard)
        widget.setWindowTitle("Library Management System")
        widget.setFixedWidth(643)
        widget.setFixedHeight(478)
        widget.move(470,130)
        widget.show()
        try:
            sys.exit(app.exec_())
        except:
            print("Exiting")
    else:
        app = QApplication(sys.argv)
        widget = QStackedWidget()
        login = Login()
        login.show()
        try:
            sys.exit(app.exec_())
        except:
            print("Exiting")