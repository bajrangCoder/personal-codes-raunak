import customtkinter
import tkinter
from tkinter import ttk
from database import LMS
from tkinter.messagebox import showinfo

db = LMS("db/lms.db")

class ViewBooks(customtkinter.CTk):
    def __init__(self):
        super().__init__()
        self.title("Library Management System")
        self.minsize(600,500)
        self.maxsize(600,500)
        self.geometry('600x500')
        
        heading_frame = customtkinter.CTkFrame(master=self,corner_radius=10)
        heading_frame.pack(padx=10,pady=10, ipadx=20, ipady=5,fill="x",anchor="n")
        
        label = customtkinter.CTkLabel(master=heading_frame, text="View Book",font=customtkinter.CTkFont(family="Robot",size=25, weight="bold"))
        label.pack(ipady=10)
        
        main_frame = customtkinter.CTkFrame(master=self,corner_radius=10)
        main_frame.pack(padx=10,pady=10, ipadx=5, ipady=5,fill="both",expand=True)
        
        columns = ('first_name', 'last_name', 'email')

        self.tree = ttk.Treeview(main_frame, columns=columns, show='headings')
        
        # define headings
        self.tree.heading('first_name', text='First Name')
        self.tree.heading('last_name', text='Last Name')
        self.tree.heading('email', text='Email')
        
        # generate sample data
        contacts = []
        for n in range(1, 100):
            contacts.append((f'first {n}', f'last {n}', f'email{n}@example.com'))
        
        # add data to the treeview
        for contact in contacts:
            self.tree.insert('', tkinter.END, values=contact)
        
        self.tree.bind('<<TreeviewSelect>>', self.item_selected)
        
        self.tree.pack()
        
        # add a scrollbar
        scrollbar = ttk.Scrollbar(main_frame, orient=tkinter.VERTICAL, command=self.tree.yview)
        scrollbar1 = ttk.Scrollbar(main_frame, orient=tkinter.HORIZONTAL, command=self.tree.xview)
        self.tree.configure(yscroll=scrollbar.set,xscroll=scrollbar1.set)
        scrollbar1.pack(side=tkinter.BOTTOM,anchor="s")
        scrollbar.pack(side=tkinter.RIGHT, anchor="e" )

    def item_selected(self,event):
        for selected_item in self.tree.selection():
            item = self.tree.item(selected_item)
            record = item['values']
            # show a message
            showinfo(title='Information', message=','.join(record))



